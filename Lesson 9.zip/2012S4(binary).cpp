#include <cstdio>
#include <cstring>
#include <queue>
#include <vector>
#include <unordered_set>
#include <set>
using namespace std;
const int N = 7;
int n;
//int16_t

//获取状态u中第i个硬币的位置
//u:   001 100 010 110 011 110 101
//i: 3
//ans:                         110
int getPosition(int32_t u, int i){
    return (u >> (3*i)) & 7;
}
//将状态u中第i个硬币的位置设置为pos，返回结果状态
/*u:          001 100 010 110 011 110 101
//i: 3
//pos:                                011
//pos<<(3*i): 000 000 000 011 000 000 000
//7<<(3*i):   000 000 000 111 000 000 000
p=~(7<<(3*i)):111 111 111 000 111 111 111
//u:          001 100 010 110 011 110 101
//u & p:      001 100 010[000]011 110 101
//ans = (u & p) | (pos<<(3*i))
//ans:        001 100 010[011]011 110 101  */
int32_t setPosition(int32_t u, int i, int pos){
    int32_t p = ~(7 << (3*i));
    return (u & p) | (pos << (3*i));
}
//从状态u出发能一步可达的所有状态
bool vis[N+1];
vector<int32_t> getNext(int32_t u){
    vector<int32_t> res;
    memset(vis, 0, sizeof(vis));
    for(int i=0;i<n;i++){
        int a = getPosition(u, i);
        if(vis[a])//当前位置a已经有一个比i小的硬币了
            continue;
        vis[a] = true;
        if(a>0 && !vis[a-1]){
            int32_t v = setPosition(u, i, a-1);
            res.push_back(v);
        }
        if(a<n-1 && !vis[a+1]){
            int32_t v = setPosition(u, i, a+1);
            res.push_back(v);
        }
    }
    return res;
}

int ans[1<<21];
int bfs(int32_t s){
    int32_t t = 0;
    for(int i=0;i<n;i++)
        t = setPosition(t, i, i);
    memset(ans, -1, sizeof(ans));
    queue<int32_t> Q;
    ans[s] = 0;
    Q.push(s);
    while(!Q.empty()){
        int32_t u = Q.front(); Q.pop();
        if(u == t)
            return ans[u];
        for(int32_t v : getNext(u)){
            if(ans[v] >= 0) continue;
            ans[v] = ans[u] + 1;
            Q.push(v);
        }
    }
    return -1;
}

int main(){
    while(true){
        scanf("%d", &n);
        if(!n) break;
        int32_t s = 0;
        for(int i=0;i<n;i++){
            int a;
            scanf("%d", &a), a--;
            s = setPosition(s, i, a);
        }
        int ans = bfs(s);
        if(ans >= 0) printf("%d\n", ans);
        else puts("IMPOSSIBLE");
        //printf("...\n"); <=> puts("...");
    }
    return 0;
}