#include <cstdio>
#include <vector>
#include <algorithm>
using namespace std;


const int N = 100000;
int prime[N+1];
//获取<=N的所有素数的素数表,prime[0]表示素数个数
void getPrimeNumbers(){
    for(int i=2;i<=N;i++){
        if(prime[i]==0) prime[++prime[0]] = i;
        for(int j=1; j<=prime[0] && prime[j]<=N/i; j++){
            prime[prime[j]*i] = 1;//not prime
            if(i%prime[j] == 0) break;
        }
    }
}
vector<pair<long long, int>> getFactors(long long x){
    vector<pair<int, int>> res;
    for(int i=1;i<=prime[0] && prime[i]<=x/prime[i]; i++){
        if(x%prime[i] == 0){
            pair<int, int> p = make_pair(prime[i], 0);
            do{
                x /= prime[i];
                p.second++;
            }while(x%prime[i] == 0);
            res.push_back(p);
        }
    }
    if(x != 1)
        res.push_back(make_pair(x, 1));
    return res;
}

// return (a ^ n) % mod
long long pow(long long a, long long n, long long mod){
    long long res = 1;
    while(n){
        if(n&1LL) res = (res*a)%mod;
        a = (a*a)%mod;
        n >>= 1;
    }
    return res;
}
//如果a,b都在[0,mod)之间，(a*b)%mod=1，那么a,b互为在mod取模的意义下的逆元
//在对mod取模的意义下求a^(-1)
//欧拉函数：(a^(mod-1))%mod = 1
//        ((a)*(a^(mod-2)%mod))%mod = 1
//要求a和mod互素，mod是素数
long long inv(long long a, long long mod){
    return pow(a, mod-2, mod);
}
//拓展欧几里得求逆元，要求a和m互素，并且a<m
long long inv2(long long a, long long mod){
    if(a == 1) return 1;
    return inv2(mod%a, mod)*(mod-mod/a)%mod;
}
//f[x] = x!,  g[x] = f[x]^(-1) 在对mod取模的意义下
long long f[N], g[N];
void init(long long mod){
    f[0] = 1;
    for(int i=1;i<N;i++){
        f[i] = (f[i-1] * i)%mod;
        g[i] = inv(f[i]);
        //g[i] = (g[i-1] * inv(i))%mod;
    }
}
// (a / b)%c != ((a%c) / (b%c))%c
//从n个球中取m个球的取法总数，组合数(n choose m)
long long choose(long long n, long long m){
    //return f[n] / f[m] / f[n-m]; // wrong
    return (((f[n] * g[m])%mod) * g[n-m])%mod;
}

const int M = 200;
int n, m;//n个方程m个未知数
double a[M][M], b[M];
/*
a[0][0]*x[0] + a[0][1]*x[1]+...+a[0][m-1]*x[m-1]=b[0]
a[1][0]*x[0] + a[1][1]*x[1]+...+a[1][m-1]*x[m-1]=b[1]
a[2][0]*x[0] + a[2][1]*x[1]+...+a[2][m-1]*x[m-1]=b[2]
...
a[n-1][0]*x[0] + a[n-1][1]*x[1]+...+a[n-1][m-1]*x[m-1]=b[n-1]
*/
/*
3x+4y+2z=7
2x+0y-3z=3
7x-2y+2z=1
*/
//执行完Gauss函数后，b数组剩下的就是未知数的解，返回值是是否有解
bool Gauss(){
    //当前拿到第k个方程，我们要把其他所有方程的第col个未知数系数变为0
    for(int k=0,col=0;k<n && col<m;k++,col++){
        //Step 0: 从所有方程中找到第col个未知数系数最大的那一个,跟第k个方程交换
        int r = k;
        for(int i=k+1;i<n;i++)
            if(fabs(a[i][col]) > fabs(a[r][col]))
                r = i;
        if(fabs(a[r][col]) < 1e-8) return false;//无解
        if(r != k){
            //交换第k个方程和第r个方程，注意col列之前的系数为0不需要交换
            for(int j=col;j<m;j++) swap(a[k][j], a[r][j]);
            swap(b[k], b[r]);
        }
        //Step 1: 把第k个方程的第col个未知数系数变为1
        b[k] /= a[k][col];
        for(int j=col+1;j<m;j++) a[k][j] /= a[k][col];
        a[k][col] = 1;
        //Step 2: 把其他所有方程的第col个未知数系数变为0
        for(int i=0;i<n;i++) if(i != k){
            b[i] -= b[k] * a[i][k];
            for(int j=col+1;j<m;j++) a[i][j] -= a[k][j]*a[i][col];
            a[i][col] = 0;
        }
    }
    return true;
}